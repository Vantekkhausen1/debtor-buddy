export interface Claim {
  AZ: string; Merker: boolean; Anrede: number | null; Name1: string; Betreff: string;
  V_Name1: string; Erledigt: boolean; Forderungsart: string; Kosten: number; Zinsen: number;
  Hauptforderung: number; Gesamtforderung: number; Stand: string; Gl_Kosten: number | null;
  Gl_Zinsen: number | null; Gl_Hauptforderung: number | null; Gl_Gesamtforderung: number | null;
  Forderungsgrund: string; geprueft: boolean; Inso: boolean; Deliktisch: boolean; Art: string;
  Haftungsgrenze: number | null; Ratenverpflichtung: number; Rate: number; RateIst: number | null;
  Verfahrensstand: string; Regulierungssumme: number; Anteil: number; Quote: number | null;
  Vergleich: number | null; Regulierungsrate: number; Laufzeit: number; Stundung: number | null;
  Abtretung: number | null; Reg_Status: number | null; Reg_Frist: number | null; Reg_Zahlungstermin: number | null;
}
